To deploy, copy the following files to a web accessible folder:

-   advisors.html
-   lookup.js
-   data.json

You must generate the file, 'data.json' from your Excel spreadsheet. To do this, 

1.  Create a spreadsheet that contains just two columns, with the headers "ulid" and "advisor".

2.  Save this spreadsheet as a CSV file.

3.  Convert this CSV file to a JSON file, named 'data.json'.

For step (3), I used this website:

-   <http://www.cparker15.com/code/utilities/csv-to-json/>

